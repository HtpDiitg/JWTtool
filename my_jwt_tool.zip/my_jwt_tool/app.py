import argparse
import jwt


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("-tok", "--token", help = "Specify your JWT using one of this parameters")
    parser.add_argument("-sec", "--secret", help = "Use this options for HS256,HS384,HS512 algorithms")
    parser.add_argument("-pub", "--public", help = "Specify path to a .txt file, which contains your public key, from your current location")
    parser.add_argument("-priv", "--private", help = "Specify path to a .txt file, which contains your private key, from your current location")
    return parser.parse_args()

def hs_validation(token, header, headers, secret):
    decoded_jwt = jwt.decode(token, key=secret, algorithms=[header, ])
    print("\n", headers)
    print(decoded_jwt)    

def rs_validation():
    #decoded_jwt = jwt.decode(token, key='secret', algorithms=['RS256', ])
    print("\n", headers)
    print(decoded_jwt)

def read_public_key(path_to_public_key):
    print('pub')
    with open(path_to_public_key) as f:
        public_key = f.read()
        print("\n\n", public_key)

def read_private_key(path_to_private_key):
    print('priv')
    with open(path_to_private_key) as f:
        private_key = f.read()
        print("\n\n", private_key)

def main(args):
    '''
    if os.geteuid() != 0:
        exit("This tool needs root privileges!")
    '''

    '''
    if args.summary is not None:
        numbers = args.summary
        numb = numbers.split(',')
        print(numb)
    '''

    print("\nProcessing..")


    if args.token is not None:
        token = args.token
    else:
        exit("[Error!] - Please, specify token using \"-tok\" or \"--token\"\n")

    if args.secret is not None:
        secret = args.secret
    else:
        exit("[Error!] - Please, specify for token validation")

    if args.public is not None:
        path_to_public_key = args.public
        print(path_to_public_key)

    if args.private is not None:
        path_to_private_key = args.private
        print(path_to_private_key)

        
    
    headers = jwt.get_unverified_header(token)
    header_alg = jwt.get_unverified_header(token)['alg']

    print(header_alg)
    if header_alg == 'HS256' or header_alg == 'HS384' or header_alg == 'HS512':
        hs_validation(token, header_alg, headers, secret)
    elif header_alg == 'RS256' or header_alg == 'RS384' or header_alg == 'RS512':
        #rs_validation(path_to_public_key, path_to_private_key)
        read_private_key(path_to_private_key)
        read_public_key(path_to_public_key)
    elif header_alg == 'ES256' or header_alg == 'ES384' or header_alg == 'ES512' or header_alg == 'PS256' or header_alg == 'PS384' or header_alg == 'PS512':
        exit("Unfortunately, current version does not support this algorithm")
    else:
        exit("We encountered some problem with the name of your algorihm, please, recheck it, every space is important!")
    


main(parse_args())







'''
Supports only HS and RS algorithms!!!

Think about workflow, how it will work (depends on param)

'''







    #token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.XbPfbIHMI6arZ3Y922BhjWgQzWXcXNrz0ogtVhfEd2o'
    #print(jwt.get_unverified_header(token))  # output header
    #print(jwt.get_unverified_header(token)['alg'])  # output alg's value
    #alg = jwt.get_unverified_header(token)['alg']
    #print(alg)

    


    #print(jwt.decode(token, key='secret', algorithms=['HS256', ]))  # decode hs256

    #jwt.decode(token, key='secret', algorithms=['RS256', ])  # decode rs256

    #print(type(jwt.get_unverified_header(token)))
